from flask import Flask, request, jsonify
import os
import PyPDF2
from docx import Document
import uuid
from flask_cors import CORS

app = Flask(__name__)

# Enable CORS for all routes
CORS(app)

# Configure upload folder
UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Function to extract text from PDF
def extract_text_from_pdf(filepath):
    text = ""
    with open(filepath, 'rb') as file:
        pdf_reader = PyPDF2.PdfReader(file)
        for page in pdf_reader.pages:
            text += page.extract_text()
    return text

# Function to extract text from DOCX
def extract_text_from_docx(filepath):
    doc = Document(filepath)
    text = []
    for para in doc.paragraphs:
        text.append(para.text)
    return '\n'.join(text)

# Function to process text for keyword matching and formatting
def process_resume_and_job_description(resume_text, job_description_text):
    job_keywords = {'Python', 'Java', 'Machine Learning', 'SQL', 'Project Management'}
    resume_words = set(resume_text.split())

    matching_keywords = job_keywords.intersection(resume_words)
    missing_keywords = job_keywords - matching_keywords

    formatting_issues = []
    if "Experience" not in resume_text:
        formatting_issues.append("Missing 'Experience' section.")
    if "Education" not in resume_text:
        formatting_issues.append("Missing 'Education' section.")

    relevance_score = len(matching_keywords) / len(job_keywords) * 100

    return {
        "ats_score": int(relevance_score),
        "missing_keywords": list(missing_keywords),
        "formatting_issues": formatting_issues
    }

@app.route('/upload-resume', methods=['POST'])
def upload_resume():
    resume_file = request.files.get('resume')
    if resume_file:
        # Generate unique file name to avoid overwriting
        unique_filename = str(uuid.uuid4()) + os.path.splitext(resume_file.filename)[-1]
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        resume_file.save(filepath)

        # Extract text based on file type
        if resume_file.filename.endswith('.pdf'):
            resume_text = extract_text_from_pdf(filepath)
        elif resume_file.filename.endswith('.docx'):
            resume_text = extract_text_from_docx(filepath)
        elif resume_file.filename.endswith('.txt'):
            resume_text = resume_file.read().decode('utf-8')
        else:
            return jsonify({"error": "Unsupported file format"}), 400

        return jsonify({"message": "Resume uploaded successfully", "resume_text": resume_text})
    
    return jsonify({"error": "No resume provided"}), 400

@app.route('/upload-job-description', methods=['POST'])
def upload_job_description():
    data = request.get_json()
    resume_text = data.get('resume_text')
    job_description_text = data.get('job_description')

    if not resume_text or not job_description_text:
        return jsonify({"error": "Both resume and job description are required"}), 400

    result = process_resume_and_job_description(resume_text, job_description_text)

    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
